"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import DimensionCard from "./dimension-card"
import RulesManager from "./rules-manager"
import { Loader2, RotateCcw, FileText, AlertCircle } from "lucide-react"

interface SelectedIndicators {
  [dimensionId: string]: {
    name: string
    subIndicators: Array<{
      id: string
      name: string
      description: string
      rules: string[]
    }>
  }
}

interface EvaluationDimensionsProps {
  fileName: string
  fileSize: number
  onGenerateReport: (selectedIndicators: SelectedIndicators) => void
  isLoading: boolean
  onReplaceFile: () => void
}

const DIMENSIONS = [
  {
    id: "completeness",
    name: "A. 完整性 (Completeness)",
    description: "确保文物元数据的完整性",
    subIndicators: [
      {
        id: "metadata_completeness",
        name: "A1. 元数据完整性",
        description: "核心数据项（如文物编号、名称、朝代、出土时间等）不能缺失。",
      },
      {
        id: "content_completeness",
        name: "A2. 内容完整性",
        description:
          '每条文物数据记录应包含文物所有必需字段，具有完整的描述信息。例如，"青铜鼎"记录必须包含文物编号、名称、朝代、出土时间等。仅有"文物名称"而其他字段为空的记录视为不完整。',
      },
    ],
  },
  {
    id: "standardization",
    name: "B. 规范性 (Standardization)",
    description: "验证数据格式和结构合规性",
    subIndicators: [
      {
        id: "format_standardization",
        name: "B1. 数据格式规范性",
        description: "数据格式（包括数据类型、长度、精度等）是否满足预期要求。",
      },
      {
        id: "redundancy_rate",
        name: "B2. 数据冗余率",
        description: "对于博物馆特定的文物，应当只有一条核心数据记录代表该文物。",
      },
      {
        id: "security_compliance",
        name: "B3. 安全合规性",
        description: "衡量数据是否符合安全和隐私规则。",
      },
    ],
  },
  {
    id: "accuracy",
    name: "C. 准确性 (Accuracy)",
    description: "根据业务规则验证数据",
    subIndicators: [
      {
        id: "content_accuracy",
        name: "C1. 数据内容准确性",
        description: "元数据内容应准确反映文物的实际信息，不存在错误或歧义描述。",
      },
    ],
  },
  {
    id: "consistency",
    name: "D. 一致性 (Consistency)",
    description: "确保关联数据的一致性",
    subIndicators: [
      {
        id: "association_consistency",
        name: "D1. 数据关联一致性",
        description: "文物数据项满足定义的一致性约束的程度（例如，朝代和出土时间必须匹配）。",
      },
      {
        id: "semantic_consistency",
        name: "D2. 元数据语义一致性",
        description:
          '确保同一元数据项在不同文物中有一致的含义，避免概念混淆。例如，"地点"字段不应该对某些文物指"出土地点"，对其他文物指"创作地点"。',
      },
    ],
  },
  {
    id: "timeliness",
    name: "E. 及时性 (Timeliness)",
    description: "验证数据的时效性",
    subIndicators: [
      {
        id: "data_timeliness",
        name: "E1. 数据及时性",
        description: "动态数据（如文物当前位置、展览状态、修复进度等）应根据实际变化及时更新。",
      },
    ],
  },
  {
    id: "authority",
    name: "F. 权威性 (Authority)",
    description: "验证数据来源的权威性",
    subIndicators: [
      {
        id: "source_authority",
        name: "F1. 数据来源权威性",
        description: "数据来自合法和经过验证的来源，内容真实、可靠、具有权威性。",
      },
    ],
  },
  {
    id: "comprehensibility",
    name: "G. 可理解性 (Comprehensibility)",
    description: "确保数据内容清晰易懂",
    subIndicators: [
      {
        id: "content_comprehensibility",
        name: "G1. 数据内容可理解性",
        description: "文本内容应表述清晰、连贯，专业术语应充分解释，便于用户（包括非专业人士）理解。",
      },
    ],
  },
]

const STORAGE_KEY = "evaluation_selections"
const RULES_STORAGE_KEY = "evaluation_rules"

const DEFAULT_SELECTIONS = () => {
  const initial: Record<string, Set<string>> = {}
  const initialChecked: Record<string, boolean> = {}
  DIMENSIONS.forEach((dim) => {
    initial[dim.id] = new Set(dim.subIndicators.map((sub) => sub.id))
    initialChecked[dim.id] = true
  })
  return { selections: initial, checked: initialChecked }
}

const serializeSelections = (selections: Record<string, Set<string>>, checked: Record<string, boolean>) => {
  return JSON.stringify({
    selections: Object.fromEntries(Object.entries(selections).map(([key, set]) => [key, Array.from(set)])),
    checked,
  })
}

const deserializeSelections = (json: string) => {
  try {
    const data = JSON.parse(json)
    return {
      selections: Object.fromEntries(
        Object.entries(data.selections).map(([key, arr]) => [key, new Set(arr as string[])]),
      ),
      checked: data.checked,
    }
  } catch {
    return null
  }
}

export default function EvaluationDimensions({
  fileName,
  fileSize,
  onGenerateReport,
  isLoading,
  onReplaceFile,
}: EvaluationDimensionsProps) {
  const [selectedDimensions, setSelectedDimensions] = useState<Record<string, Set<string>>>(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (saved) {
      const deserialized = deserializeSelections(saved)
      return deserialized?.selections || DEFAULT_SELECTIONS().selections
    }
    return DEFAULT_SELECTIONS().selections
  })

  const [dimensionChecked, setDimensionChecked] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (saved) {
      const deserialized = deserializeSelections(saved)
      return deserialized?.checked || DEFAULT_SELECTIONS().checked
    }
    return DEFAULT_SELECTIONS().checked
  })

  const [rules, setRules] = useState<Record<string, string[]>>(() => {
    const saved = localStorage.getItem(RULES_STORAGE_KEY)
    if (saved) {
      try {
        return JSON.parse(saved)
      } catch {
        return {}
      }
    }
    return {}
  })

  const [toast, setToast] = useState<{ message: string; type: "success" | "info" } | null>(null)

  const showToast = (message: string, type: "success" | "info" = "success") => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 3000)
  }

  const handleDimensionToggle = (dimensionId: string) => {
    setDimensionChecked((prev) => {
      const newState = { ...prev, [dimensionId]: !prev[dimensionId] }
      setSelectedDimensions((prevDims) => {
        const dimension = DIMENSIONS.find((d) => d.id === dimensionId)
        if (!dimension) return prevDims

        const newDims = { ...prevDims }
        if (newState[dimensionId]) {
          newDims[dimensionId] = new Set(dimension.subIndicators.map((sub) => sub.id))
        } else {
          newDims[dimensionId] = new Set()
        }
        return newDims
      })
      return newState
    })
  }

  const handleSubIndicatorToggle = (dimensionId: string, subIndicatorId: string) => {
    setSelectedDimensions((prev) => {
      const newDims = { ...prev }
      const newSet = new Set(newDims[dimensionId])

      if (newSet.has(subIndicatorId)) {
        newSet.delete(subIndicatorId)
      } else {
        newSet.add(subIndicatorId)
      }

      newDims[dimensionId] = newSet

      setDimensionChecked((prevChecked) => {
        const dimension = DIMENSIONS.find((d) => d.id === dimensionId)
        const allSelected = dimension ? dimension.subIndicators.every((sub) => newSet.has(sub.id)) : false
        return { ...prevChecked, [dimensionId]: allSelected }
      })

      return newDims
    })
  }

  const handleAddRule = (subIndicatorId: string, rule: string) => {
    if (!rule.trim()) return

    setRules((prev) => {
      const updated = { ...prev }
      if (!updated[subIndicatorId]) {
        updated[subIndicatorId] = []
      }
      if (!updated[subIndicatorId].includes(rule)) {
        updated[subIndicatorId] = [...updated[subIndicatorId], rule]
      }
      console.log("[v0] Rule added:", subIndicatorId, rule)
      console.log("[v0] Updated rules state:", updated)
      localStorage.setItem(RULES_STORAGE_KEY, JSON.stringify(updated))
      return updated
    })
  }

  const handleRemoveRule = (subIndicatorId: string, rule: string) => {
    setRules((prev) => {
      const updated = { ...prev }
      updated[subIndicatorId] = (updated[subIndicatorId] || []).filter((r) => r !== rule)
      console.log("[v0] Rule removed:", subIndicatorId, rule)
      console.log("[v0] Updated rules state:", updated)
      localStorage.setItem(RULES_STORAGE_KEY, JSON.stringify(updated))
      return updated
    })
  }

  const handleLoadPreset = (presetRules: Record<string, string[]>) => {
    setRules(presetRules)
    localStorage.setItem(RULES_STORAGE_KEY, JSON.stringify(presetRules))
  }

  const hasAnyDimensionSelected = useMemo(() => {
    return Object.values(dimensionChecked).some((checked) => checked)
  }, [dimensionChecked])

  const handleGenerateReport = () => {
    console.log("[v0] Current rules state before generating report:", rules)

    const payload: SelectedIndicators = {}

    DIMENSIONS.forEach((dimension) => {
      if (dimensionChecked[dimension.id]) {
        const selectedSubs = dimension.subIndicators.filter((sub) => selectedDimensions[dimension.id]?.has(sub.id))

        if (selectedSubs.length > 0) {
          payload[dimension.id] = {
            name: dimension.name,
            subIndicators: selectedSubs.map((sub) => ({
              id: sub.id,
              name: sub.name,
              description: sub.description,
              rules: rules[sub.id] || [],
            })),
          }
        }
      }
    })

    console.log("[v0] Final payload with rules:", JSON.stringify(payload, null, 2))
    onGenerateReport(payload)
  }

  const handleResetRules = () => {
    const defaults = DEFAULT_SELECTIONS()
    setSelectedDimensions(defaults.selections)
    setDimensionChecked(defaults.checked)
    setRules({})
    localStorage.removeItem(STORAGE_KEY)
    localStorage.removeItem(RULES_STORAGE_KEY)
    showToast("All settings reset to default", "info")
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i]
  }

  return (
    <div className="space-y-6 p-8">
      <Card className="bg-card border-border shadow-sm">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-accent" />
                File Ready for Evaluation
              </CardTitle>
              <CardDescription className="mt-2">
                <div className="font-mono text-foreground text-sm">{fileName}</div>
                <div className="text-xs text-muted-foreground mt-1">Size: {formatFileSize(fileSize)}</div>
              </CardDescription>
            </div>
            <Button onClick={onReplaceFile} variant="outline" className="ml-4 bg-transparent">
              Replace File
            </Button>
          </div>
        </CardHeader>
      </Card>

      <div className="pt-4">
        <RulesManager
          currentRules={Object.fromEntries(Object.entries(rules).map(([key, value]) => [key, value]))}
          onLoadRules={handleLoadPreset}
        />
      </div>

      <div className="pt-4">
        <h2 className="text-2xl font-bold text-foreground mb-6">Select Evaluation Dimensions</h2>
        <div className="grid grid-cols-1 gap-6">
          {DIMENSIONS.map((dimension) => (
            <DimensionCard
              key={dimension.id}
              dimension={dimension}
              isChecked={dimensionChecked[dimension.id]}
              selectedSubIndicators={selectedDimensions[dimension.id] || new Set()}
              onDimensionToggle={handleDimensionToggle}
              onSubIndicatorToggle={handleSubIndicatorToggle}
              rules={rules}
              onAddRule={handleAddRule}
              onRemoveRule={handleRemoveRule}
            />
          ))}
        </div>
      </div>

      <div className="space-y-4 pt-4">
        {!hasAnyDimensionSelected && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-900 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>Please select at least one evaluation dimension to generate a report.</span>
          </div>
        )}

        <div className="flex gap-3 justify-between items-center flex-wrap">
          <Button onClick={handleResetRules} variant="outline" className="flex items-center gap-2 bg-transparent">
            <RotateCcw className="w-4 h-4" />
            Reset All
          </Button>

          <Button
            onClick={handleGenerateReport}
            disabled={isLoading || !hasAnyDimensionSelected}
            className="bg-primary hover:bg-primary/90 text-primary-foreground min-w-48"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Report...
              </>
            ) : (
              "Generate AI Report"
            )}
          </Button>
        </div>
      </div>

      {toast && (
        <div
          className={`fixed bottom-4 right-4 p-4 rounded-lg text-sm font-medium transition-all ${
            toast.type === "success"
              ? "bg-green-100 text-green-800 border border-green-200"
              : "bg-blue-100 text-blue-800 border border-blue-200"
          }`}
        >
          {toast.message}
        </div>
      )}
    </div>
  )
}
