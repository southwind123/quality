"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Save, Trash2, Upload, Download, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface RulePreset {
  id: string
  name: string
  description: string
  rules: Record<string, Record<string, string[]>>
  createdAt: number
  updatedAt: number
}

interface RulesManagerProps {
  currentRules: Record<string, Record<string, string[]>>
  onLoadRules: (rules: Record<string, Record<string, string[]>>) => void
}

const STORAGE_KEY = "rule-presets"

export default function RulesManager({ currentRules, onLoadRules }: RulesManagerProps) {
  const [presets, setPresets] = useState<RulePreset[]>([])
  const [newPresetName, setNewPresetName] = useState("")
  const [newPresetDescription, setNewPresetDescription] = useState("")
  const [isOpen, setIsOpen] = useState(false)
  const { toast } = useToast()

  // Load presets from localStorage
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (saved) {
      try {
        setPresets(JSON.parse(saved))
      } catch (error) {
        console.error("Failed to load presets:", error)
      }
    }
  }, [])

  // Save presets to localStorage
  const savePresetsToStorage = (newPresets: RulePreset[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newPresets))
    setPresets(newPresets)
  }

  const saveCurrentRules = () => {
    if (!newPresetName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a preset name",
        variant: "destructive",
      })
      return
    }

    const hasRules = Object.values(currentRules).some((dimension) =>
      Object.values(dimension).some((rules) => rules.length > 0),
    )

    if (!hasRules) {
      toast({
        title: "Error",
        description: "No rules defined to save",
        variant: "destructive",
      })
      return
    }

    const newPreset: RulePreset = {
      id: Date.now().toString(),
      name: newPresetName,
      description: newPresetDescription,
      rules: currentRules,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }

    const updated = [newPreset, ...presets]
    savePresetsToStorage(updated)
    setNewPresetName("")
    setNewPresetDescription("")
    setIsOpen(false)

    toast({
      title: "Success",
      description: `Rules saved as "${newPresetName}"`,
    })
  }

  const loadPreset = (preset: RulePreset) => {
    onLoadRules(preset.rules)
    toast({
      title: "Success",
      description: `Loaded preset "${preset.name}"`,
    })
  }

  const deletePreset = (id: string) => {
    const updated = presets.filter((p) => p.id !== id)
    savePresetsToStorage(updated)
    toast({
      title: "Success",
      description: "Preset deleted",
    })
  }

  const exportPresets = () => {
    const dataStr = JSON.stringify(presets, null, 2)
    const element = document.createElement("a")
    element.href = URL.createObjectURL(new Blob([dataStr], { type: "application/json" }))
    element.download = "rule-presets.json"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const importPresets = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target?.result as string)
        if (Array.isArray(imported)) {
          const updated = [...imported, ...presets]
          savePresetsToStorage(updated)
          toast({
            title: "Success",
            description: `Imported ${imported.length} preset(s)`,
          })
        }
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to import presets",
          variant: "destructive",
        })
      }
    }
    reader.readAsText(file)
  }

  return (
    <Card className="bg-card/50 border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Save className="w-5 h-5 text-accent" />
          Manage Rule Presets
        </CardTitle>
        <CardDescription>Save and load evaluation rules for quick reuse</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Save New Preset */}
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="w-full gap-2 bg-accent hover:bg-accent/90 text-accent-foreground">
              <Plus className="h-4 w-4" />
              Save Current Rules as Preset
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Save Rule Preset</DialogTitle>
              <DialogDescription>Create a new preset from your current rules</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Preset Name *</label>
                <Input
                  placeholder="e.g., Customer Data Validation"
                  value={newPresetName}
                  onChange={(e) => setNewPresetName(e.target.value)}
                  className="bg-input text-foreground"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Description</label>
                <Input
                  placeholder="Optional description for this preset"
                  value={newPresetDescription}
                  onChange={(e) => setNewPresetDescription(e.target.value)}
                  className="bg-input text-foreground"
                />
              </div>
              <Button
                onClick={saveCurrentRules}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Save Preset
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Import/Export */}
        <div className="flex gap-2">
          <Button
            onClick={exportPresets}
            disabled={presets.length === 0}
            variant="outline"
            className="flex-1 gap-2 bg-transparent"
          >
            <Download className="h-4 w-4" />
            Export All
          </Button>
          <label>
            <input type="file" accept=".json" onChange={importPresets} className="hidden" />
            <Button asChild variant="outline" className="flex-1 gap-2 bg-transparent cursor-pointer">
              <span>
                <Upload className="h-4 w-4" />
                Import
              </span>
            </Button>
          </label>
        </div>

        {/* Presets List */}
        {presets.length > 0 ? (
          <div className="space-y-2 max-h-96 overflow-y-auto">
            <p className="text-sm font-medium text-muted-foreground">Saved Presets ({presets.length})</p>
            {presets.map((preset) => (
              <div
                key={preset.id}
                className="flex items-start justify-between p-3 bg-muted/30 border border-border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground text-sm truncate">{preset.name}</p>
                  {preset.description && <p className="text-xs text-muted-foreground truncate">{preset.description}</p>}
                  <p className="text-xs text-muted-foreground mt-1">
                    Modified: {new Date(preset.updatedAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex gap-2 ml-2">
                  <Button
                    size="sm"
                    onClick={() => loadPreset(preset)}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Load
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button size="sm" variant="ghost" className="hover:bg-destructive/10 hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Preset</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete "{preset.name}"? This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <div className="flex gap-3 justify-end">
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deletePreset(preset.id)}
                          className="bg-destructive hover:bg-destructive/90"
                        >
                          Delete
                        </AlertDialogAction>
                      </div>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-muted-foreground text-sm">
            <p>No presets saved yet</p>
            <p className="text-xs mt-1">Save your current rules to create your first preset</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
