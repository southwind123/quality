"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Copy, Download, FileText, AlertCircle } from "lucide-react"
import { useState, useMemo } from "react"
import { generatePDF } from "@/lib/pdf-generator"

interface ReportDisplayProps {
  report: string
  onBackToConfigure: () => void
  onBackToUpload: () => void
}

interface ReportSection {
  title: string
  content: string
  icon?: React.ReactNode
}

export default function ReportDisplay({ report, onBackToConfigure, onBackToUpload }: ReportDisplayProps) {
  const [copied, setCopied] = useState(false)

  // Parse report sections (heuristic based on common patterns)
  const reportSections = useMemo((): ReportSection[] => {
    const sections: ReportSection[] = []

    // Split by numbered sections or headers
    const lines = report.split("\n")
    let currentSection: ReportSection | null = null

    lines.forEach((line) => {
      if (line.match(/^#{1,3}\s/) || line.match(/^\d+\.\s/) || line.match(/^[A-Z][^a-z]*:$/)) {
        // Start new section
        if (currentSection) {
          sections.push(currentSection)
        }
        const title = line.replace(/^#+\s|^\d+\.\s|:$/, "").trim()
        currentSection = {
          title,
          content: "",
          icon:
            line.includes("Issue") || line.includes("Problem") ? (
              <AlertCircle className="w-4 h-4" />
            ) : (
              <FileText className="w-4 h-4" />
            ),
        }
      } else if (currentSection && line.trim()) {
        currentSection.content += line + "\n"
      }
    })

    if (currentSection) {
      sections.push(currentSection)
    }

    return sections.length > 0 ? sections : [{ title: "Evaluation Report", content: report }]
  }, [report])

  const handleCopy = () => {
    navigator.clipboard.writeText(report)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    const element = document.createElement("a")
    const file = new Blob([report], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = `evaluation-report-${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const handleDownloadPDF = () => {
    const today = new Date()
    const dateStr = today.toISOString().split("T")[0].replace(/-/g, "")
    const filename = `Cultural_Relic_Metadata_Quality_Report_${dateStr}.pdf`

    generatePDF({
      title: "文物数字资源元数据质量评估报告",
      content: report,
      filename,
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex gap-2">
          <Button onClick={onBackToConfigure} variant="outline" className="gap-2 bg-transparent">
            <ArrowLeft className="h-4 w-4" />
            Back to Rules
          </Button>
          <Button onClick={onBackToUpload} variant="outline" className="gap-2 bg-transparent">
            <ArrowLeft className="h-4 w-4" />
            Start Over
          </Button>
        </div>
        <div className="text-sm text-muted-foreground">
          Generated on {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
        </div>
      </div>

      <Card className="border border-accent/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-accent" />
            AI-Generated Evaluation Report
          </CardTitle>
          <CardDescription>Comprehensive analysis based on your defined evaluation rules</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Report Content Display */}
          <div className="bg-muted/30 rounded-lg p-6 border border-border min-h-96 max-h-96 overflow-y-auto">
            <div className="text-foreground whitespace-pre-wrap font-mono text-sm leading-relaxed">{report}</div>
          </div>

          {report && (
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-muted/50 rounded-lg p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">Report Length</p>
                <p className="text-lg font-semibold text-foreground">{report.length.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">characters</p>
              </div>
              <div className="bg-muted/50 rounded-lg p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">Sections</p>
                <p className="text-lg font-semibold text-foreground">{reportSections.length}</p>
              </div>
              <div className="bg-muted/50 rounded-lg p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">Lines</p>
                <p className="text-lg font-semibold text-foreground">{report.split("\n").length}</p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 flex-wrap">
            <Button onClick={handleCopy} variant="outline" className="gap-2 bg-transparent flex-1">
              <Copy className="h-4 w-4" />
              {copied ? "Copied!" : "Copy Report"}
            </Button>
            <Button
              onClick={handleDownload}
              className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground flex-1"
            >
              <Download className="h-4 w-4" />
              Download TXT
            </Button>
            <Button onClick={handleDownloadPDF} variant="outline" className="gap-2 bg-transparent flex-1">
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
