"use client"

import { Checkbox } from "@/components/ui/checkbox"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ChevronDown, Plus, X } from "lucide-react"

interface SubIndicator {
  id: string
  name: string
  description: string
}

interface Dimension {
  id: string
  name: string
  description: string
  subIndicators: SubIndicator[]
}

interface DimensionCardProps {
  dimension: Dimension
  isChecked: boolean
  selectedSubIndicators: Set<string>
  onDimensionToggle: (dimensionId: string) => void
  onSubIndicatorToggle: (dimensionId: string, subIndicatorId: string) => void
  rules: Record<string, string[]>
  onAddRule: (subIndicatorId: string, rule: string) => void
  onRemoveRule: (subIndicatorId: string, rule: string) => void
}

export default function DimensionCard({
  dimension,
  isChecked,
  selectedSubIndicators,
  onDimensionToggle,
  onSubIndicatorToggle,
  rules,
  onAddRule,
  onRemoveRule,
}: DimensionCardProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [ruleInputs, setRuleInputs] = useState<Record<string, string>>({})

  const handleAddRuleClick = (subIndicatorId: string) => {
    const ruleText = ruleInputs[subIndicatorId]?.trim()
    if (ruleText) {
      onAddRule(subIndicatorId, ruleText)
      setRuleInputs((prev) => ({ ...prev, [subIndicatorId]: "" }))
    }
  }

  return (
    <div className="rounded-2xl bg-white border border-border shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
      <div className="p-6 border-b border-border">
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-foreground">{dimension.name}</h3>
            <p className="text-sm text-muted-foreground mt-1">{dimension.description}</p>
          </div>
          <Checkbox
            checked={isChecked}
            onCheckedChange={() => onDimensionToggle(dimension.id)}
            className="mt-1 flex-shrink-0"
          />
        </div>
      </div>

      <div className="px-6">
        <Button
          onClick={() => setIsExpanded(!isExpanded)}
          variant="ghost"
          className="w-full justify-between py-4 px-0 hover:bg-muted/50 text-foreground font-medium transition-colors"
        >
          <span>Sub-Indicators ({dimension.subIndicators.length})</span>
          <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}`} />
        </Button>

        {isExpanded && (
          <div className="space-y-0 pb-6">
            {dimension.subIndicators.map((subIndicator, index) => (
              <div key={subIndicator.id}>
                <div className="py-4 px-2">
                  <div className="flex items-start gap-3 hover:bg-muted/50 rounded px-2 py-2 transition-colors">
                    <Checkbox
                      checked={selectedSubIndicators.has(subIndicator.id)}
                      onCheckedChange={() => onSubIndicatorToggle(dimension.id, subIndicator.id)}
                      className="mt-1 flex-shrink-0"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-foreground text-sm">{subIndicator.name}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{subIndicator.description}</p>
                    </div>
                  </div>

                  <div className="mt-3 ml-8 space-y-2">
                    {/* Existing rules display */}
                    {(rules[subIndicator.id] || []).length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {rules[subIndicator.id].map((rule, idx) => (
                          <div
                            key={idx}
                            className="inline-flex items-center gap-2 bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full"
                          >
                            <span>{rule}</span>
                            <button
                              onClick={() => onRemoveRule(subIndicator.id, rule)}
                              className="hover:text-blue-900 transition-colors"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Rule input field */}
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={ruleInputs[subIndicator.id] || ""}
                        onChange={(e) => setRuleInputs((prev) => ({ ...prev, [subIndicator.id]: e.target.value }))}
                        onKeyPress={(e) => {
                          if (e.key === "Enter") {
                            handleAddRuleClick(subIndicator.id)
                          }
                        }}
                        placeholder="Add a rule..."
                        className="flex-1 text-xs border border-border rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-accent bg-white"
                      />
                      <Button
                        onClick={() => handleAddRuleClick(subIndicator.id)}
                        size="sm"
                        variant="ghost"
                        className="px-2 hover:bg-muted"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {index < dimension.subIndicators.length - 1 && <div className="h-px bg-border mx-2" />}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
