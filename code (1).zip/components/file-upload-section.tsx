"use client"

import type React from "react"

import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload } from "lucide-react"

interface FileUploadSectionProps {
  onFileUpload: (file: File) => void
}

export default function FileUploadSection({ onFileUpload }: FileUploadSectionProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.currentTarget.classList.add("border-primary")
  }

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.currentTarget.classList.remove("border-primary")
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.currentTarget.classList.remove("border-primary")

    const files = e.dataTransfer.files
    if (files.length > 0) {
      const file = files[0]
      if (
        file.type.includes("spreadsheet") ||
        file.type.includes("excel") ||
        file.name.endsWith(".xlsx") ||
        file.name.endsWith(".xls")
      ) {
        onFileUpload(file)
      } else {
        alert("Please upload an Excel file (.xlsx or .xls)")
      }
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      onFileUpload(files[0])
    }
  }

  return (
    <Card className="border-2">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="w-5 h-5 text-accent" />
          Upload Excel File
        </CardTitle>
        <CardDescription>Drag and drop your Excel file or click to browse</CardDescription>
      </CardHeader>
      <CardContent>
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className="border-2 border-dashed border-border rounded-lg p-12 text-center transition-colors cursor-pointer hover:border-accent hover:bg-muted/50"
        >
          <input ref={fileInputRef} type="file" accept=".xlsx,.xls" onChange={handleFileSelect} className="hidden" />

          <div className="flex flex-col items-center gap-4">
            <div className="p-3 bg-accent/10 rounded-lg">
              <Upload className="w-6 h-6 text-accent" />
            </div>
            <div>
              <p className="text-foreground font-medium mb-1">Drop your Excel file here</p>
              <p className="text-muted-foreground text-sm">or</p>
            </div>
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              Browse Files
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
