"use client"

import { useState } from "react"
import FileUploadSection from "@/components/file-upload-section"
import EvaluationDimensions from "@/components/evaluation-dimensions"
import ReportDisplay from "@/components/report-display"

type Step = "upload" | "configure" | "report"

interface SelectedIndicators {
  [dimensionId: string]: {
    name: string
    subIndicators: Array<{
      id: string
      name: string
    }>
  }
}

interface Rules {
  [ruleId: string]: {
    name: string
    description: string
  }
}

export default function Home() {
  const [step, setStep] = useState<Step>("upload")
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [report, setReport] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)

  const [fileMetadata, setFileMetadata] = useState<{ name: string; size: number } | null>(null)
  const [selectedRules, setSelectedRules] = useState<Rules>({})

  const handleFileUpload = (file: File) => {
    setUploadedFile(file)
    setFileMetadata({
      name: file.name,
      size: file.size,
    })
    setStep("configure")
  }

  const handleGenerateReport = async (selectedIndicators: SelectedIndicators) => {
    if (!uploadedFile) return

    setIsLoading(true)
    try {
      const formData = new FormData()
      formData.append("file", uploadedFile)
      formData.append("selectedIndicators", JSON.stringify(selectedIndicators))
      formData.append("selectedRules", JSON.stringify(selectedRules))

      const response = await fetch("/api/analyze", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) throw new Error("Failed to generate report")

      // Read streaming text response instead of JSON
      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let reportText = ""

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value, { stream: true })
          reportText += chunk
          // Optionally update report in real-time for better UX
          setReport(reportText)
        }
      }

      console.log("[v0] Streaming completed successfully")
      setStep("report")
    } catch (error) {
      console.error("Error generating report:", error)
      alert("Failed to generate report")
    } finally {
      setIsLoading(false)
    }
  }

  const handleBackToUpload = () => {
    setStep("upload")
    setUploadedFile(null)
    setFileMetadata(null)
    setReport("")
    setSelectedRules({})
  }

  const handleBackToConfigure = () => {
    setStep("configure")
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-2">Data Evaluation Suite</h1>
          <p className="text-muted-foreground">Upload your Excel file and select evaluation dimensions</p>
        </div>

        {step === "upload" && <FileUploadSection onFileUpload={handleFileUpload} />}

        {step === "configure" && uploadedFile && (
          <EvaluationDimensions
            fileName={uploadedFile.name}
            fileSize={uploadedFile.size}
            onGenerateReport={handleGenerateReport}
            isLoading={isLoading}
            onReplaceFile={() => setStep("upload")}
            selectedRules={selectedRules}
            setSelectedRules={setSelectedRules}
          />
        )}

        {step === "report" && (
          <ReportDisplay
            report={report}
            onBackToConfigure={handleBackToConfigure}
            onBackToUpload={handleBackToUpload}
          />
        )}
      </div>
    </main>
  )
}
