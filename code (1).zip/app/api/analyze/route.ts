import { type NextRequest, NextResponse } from "next/server"
import { Buffer } from "buffer"

export const maxDuration = 60

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File
    const selectedIndicatorsJson = formData.get("selectedIndicators") as string

    if (!file || !selectedIndicatorsJson) {
      return NextResponse.json({ error: "Missing file or indicators" }, { status: 400 })
    }

    let selectedIndicators: Record<string, any> = {}
    try {
      selectedIndicators = JSON.parse(selectedIndicatorsJson)
    } catch (e) {
      return NextResponse.json({ error: "Invalid indicators format" }, { status: 400 })
    }

    // Parse Excel file
    const arrayBuffer = await file.arrayBuffer()
    const fileBuffer = Buffer.from(arrayBuffer)

    const XLSX = await import("xlsx")
    const workbook = XLSX.read(fileBuffer, { type: "buffer" })

    const firstSheetName = workbook.SheetNames[0]
    const worksheet = workbook.Sheets[firstSheetName]
    const records = XLSX.utils.sheet_to_json(worksheet, { defval: "" })

    // Build rules document from selected indicators
    let rulesDocument = "## 质量评估指标与规则\n\n"

    Object.entries(selectedIndicators).forEach(([dimensionId, dimensionData]: [string, any]) => {
      if (dimensionData.name) {
        rulesDocument += `## ${dimensionData.name}\n\n`

        if (dimensionData.subIndicators) {
          dimensionData.subIndicators.forEach((sub: any) => {
            rulesDocument += `### ${sub.name}\n\n`
            if (sub.description) {
              rulesDocument += `**二级指标说明：** ${sub.description}\n\n`
            }
            if (sub.rules && sub.rules.length > 0) {
              rulesDocument += `**用户自定义规则：**\n`
              sub.rules.forEach((rule: string) => {
                rulesDocument += `- ${rule}\n`
              })
              rulesDocument += "\n"
            } else {
              rulesDocument += `**用户自定义规则：** 无\n\n`
            }
          })
        }
      }
    })

    console.log("[v0] Rules document:\n", rulesDocument)

    // Prepare data summary for prompt
    const columnNames = Object.keys(records[0] || {})
    const dataSummary = {
      totalRecords: records.length,
      columns: columnNames,
      sampleRows: records,
      emptyFieldStats: columnNames.reduce(
        (acc, col) => {
          const emptyCount = records.filter((r: any) => !r[col] || r[col].toString().trim() === "").length
          return { ...acc, [col]: `${((emptyCount / records.length) * 100).toFixed(1)}%` }
        },
        {} as Record<string, string>,
      ),
    }

    const evaluationPrompt = `你是一个文物数字资源元数据质量评估专家。请根据以下质量评估指标和规则，对提供的文物数据进行质量评估。

${rulesDocument}

## 数据概况

- 总记录数：${dataSummary.totalRecords}
- 数据列：${dataSummary.columns.join(", ")}
- 前5条示例数据：
${JSON.stringify(dataSummary.sampleRows, null, 2)}

## 空值统计
${JSON.stringify(dataSummary.emptyFieldStats, null, 2)}

## 评估要求

你需同时扮演「全量数据校验代码生成专家」和「语义分析 + 报告整合专家」，通过 “AI 规划代码逻辑→代码全量精准校验→AI 语义深化分析→结构化报告生成” 的流程，基于提供的文物元数据结构化数据，生成符合要求的详细中文质量报告，解决大量数据人工校验遗漏、精准度不足的问题。

核心总则（贯穿全流程，100% 强制执行）
（1）数据唯一性原则：所有代码生成、校验逻辑、报告内容，必须以「上传的文物元数据结构化文件（Excel）」为唯一依据，拒绝任何预设示例（如示例编号、示例字段缺失情况）、虚构数据、格式套用，全程绑定实际数据的字段结构、原始内容、真实记录；
（2）代码适配性原则：AI 生成的校验代码必须自动适配实际数据结构，无需手动指定字段名 / 数据格式，自动识别实际存在的字段、藏品编号原始格式、数据类型，避免 “预设字段与实际不符” 导致的校验错误；
（3）全量精准原则：代码必须逐行全量扫描所有文物记录，无抽样、无遗漏；报告必须呈现所有实际存在的质量问题，无概括省略、无编号编造、无字段误标；
（4）可追溯原则：所有不合规率、统计数据、问题记录，均需可追溯至实际数据（如不合规率 = 实际问题记录数 / 实际总记录数，问题记录的藏品编号可在原始数据中查到）。
（5）基于结构化校验结果，输出 “数据事实 + 语义解读” 的组合内容，不添加无关推测，所有解读均基于校验数据。

代码禁止行为
（1）禁止预设字段名；
（2）禁止编造问题记录（如代码逻辑中无 “随机生成问题”“套用示例编号”）。

使用【AI 规划 + 生成全量校验代码】以及【大语言模型理解能力】来生成报告：
1 完整性
1.1 元数据完整性
自动识别数据集中实际包含的核心数据项（对照固定核心项：规则中标明了），统计 “已包含项”“缺失项”，计算不合规率（缺失项数 / 总核心项数 ×100%）；
1.2 内容完整性
逐行扫描每条记录，识别 “数据集中已存在核心数据项” 的缺失情况，输出 “文物编号（具体是否叫文物编号结合数据情况） + 缺失字段” 的结构化清单，即：
（1）先读取数据，自动识别「数据中实际存在的字段」（比如你的数据中实际有：藏品编号、藏品名称、年代、质地、类别、级别、尺寸）；
（2）逐行遍历每条文物记录，对单条记录：
     识别「哪些核心字段缺失」；
     提取「哪些核心字段未缺失」及对应的原始值（保留完整信息，不修改格式）；
对于有缺失字段的文物条目，整理成结构化清单，每条记录包含：未缺失字段及值、缺失字段，支持后续生成报告或导出为 CSV。
以「单条文物记录」为最小单位，生成全量结构化清单：仅保留 “存在字段缺失” 的文物记录，每条记录独立对应一个质量问题，包含该文物的「所有未缺失字段及原始值」+「缺失字段」，不按缺失字段汇总统计数量，直接以csv格式写入报告中。

2 规范性
2.1 数据格式规范性
结合大语言模型理解能力逐条扫描每一条文物数据，看其某一列（数据项）是否有与其他文物数据格式不同的，如有，详细列出。整理成结构化清单（字典列表），每条记录包含这条文物信息的全部字段，说明哪个字段格式不同。
2.2 数据冗余率
校验完全重复记录（藏品编号不同但名称、年代、质地、类别、级别、尺寸完全一致），输出重复记录对 / 组；可使用python去查找是否存在一样的文物数据记录。
2.3 安全规范
数据符合安全和隐私方面规则的度量。这个结合大语言模型理解能力逐条扫描每一条文物数据，判断数据符合安全和隐私方面规则的度量。若不符合列出具体为哪一个文物

3 准确性
3.1 数据内容准确性
元数据内容应精确地反映文物实际信息，不得出现错误或模糊描述。这个结合大语言模型理解能力逐条扫描每一条文物数据并结合大语言模型对于文物的知识判断每一条文物信息是否有错误。
4 一致性
4.1 数据关联一致性
文物数据项之间应满足定义好的一致性约束准则的程度（如所属朝代与出土时间应匹配）。这个结合大语言模型理解能力逐条扫描每一条文物数据并结合大语言模型对于文物的知识判断每一条文物信息是否有错误。
4.2 元数据语义一致性
应保证同一元数据项在不同文物中含义一致，避免概念混用。如“地点”字段在某些文物中表示“出土地点”，而在其他文物中表示“创作地点”，会导致数据语义混乱。这个结合大语言模型理解能力逐条扫描每一条文物数据并结合大语言模型对于文物的知识判断每一条文物信息是否有错误。
5 时效性
5.1 数据及时性
动态数据（如文物当前所在位置、展览状态、修复进度等）应根据实际变化及时更新。这个结合大语言模型理解能力逐条扫描每一条文物数据并结合大语言模型对于文物的知识判断每一条文物信息是否有错误。
6 权威性
6.1 数据源权威性
来源正规合法（经过检验）数据内容真实可靠、准确权威。检查是否有数据来源信息。
7 可理解性
7.1 数据内容可理解性
校验文本字段无生僻术语 / 模糊表述。这个结合大语言模型理解能力逐条扫描每一条文物数据并结合大语言模型对于文物的知识判断每一条文物信息是否有错误。
第一步：AI 规划 + 生成全量校验代码（核心要求）


AI 生成结构化报告（严格遵循以下要求）
1. 报告结构要求
每个子项需包含：详细评估（结合代码校验逻辑 + AI 语义分析）、质量问题（逐一列出全量问题记录）、不合规率（精准到 2 位小数）；
核心数据项对照标准、已包含项、缺失项需完整列出，不可用 “等” 省略。
2. 报告内容要求
质量问题：严格沿用代码校验的结构化结果，逐一列出所有问题记录，结合 AI 语义分析补充问题表现；
不合规率：直接采用代码计算的精准数值，不手动调整；
结论：结合代码校验的精准数据（如 “完整性不合规率 36.36%，为最高”）和 AI 语义分析（如 “年代缺失为主要问题”），明确整体质量等级，给出可操作的优化建议（如 “优先补充年代字段，统一尺寸字段维度标注规范”）。
最终输出要求

生成的报告应该结构清晰、逻辑严谨、数据准确。`

    const apiKey = process.env.DOUBAO_API_KEY
    const model = process.env.DOUBAO_MODEL || "ep-20251106181559-nvkpp"

    if (!apiKey) {
      return new Response(JSON.stringify({ error: "未配置 DOUBAO_API_KEY 环境变量，请在项目的 Vars 部分设置" }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      })
    }

    console.log("[v0] Calling Doubao API with streaming...")

    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        try {
          const response = await fetch("https://ark.cn-beijing.volces.com/api/v3/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
              model: model,
              messages: [
                {
                  role: "system",
                  content: "你是一个专业的文物数字资源元数据质量评估专家，擅长识别数据质量问题并生成详细的评估报告。",
                },
                {
                  role: "user",
                  content: evaluationPrompt,
                },
              ],
              temperature: 0.7,
              max_tokens: 8000,
              stream: true,
            }),
          })

          if (!response.ok) {
            const errorText = await response.text()
            console.error("[v0] Doubao API error:", errorText)
            controller.enqueue(encoder.encode(`生成报告时出错: ${errorText}`))
            controller.close()
            return
          }

          const reader = response.body?.getReader()
          if (!reader) {
            controller.enqueue(encoder.encode("错误：无响应内容"))
            controller.close()
            return
          }

          const decoder = new TextDecoder()
          let buffer = ""
          let totalContent = ""

          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            buffer += decoder.decode(value, { stream: true })
            const lines = buffer.split("\n")
            buffer = lines.pop() || ""

            for (const line of lines) {
              if (line.trim() === "" || line.trim() === "data: [DONE]") continue
              if (line.startsWith("data: ")) {
                try {
                  const json = JSON.parse(line.slice(6))
                  if (json.choices && json.choices.length > 0) {
                    const content = json.choices[0]?.delta?.content || json.choices[0]?.message?.content
                    if (content) {
                      totalContent += content
                      console.log("[v0] Received content chunk, total length:", totalContent.length)
                      controller.enqueue(encoder.encode(content))
                    }
                  }
                } catch (e) {
                  console.error("[v0] Failed to parse SSE line:", line, e)
                }
              }
            }
          }

          console.log("[v0] Streaming completed successfully, total content length:", totalContent.length)
          controller.close()
        } catch (error: any) {
          console.error("[v0] Streaming error:", error)
          controller.enqueue(encoder.encode(`\n\n生成报告时出错: ${error.message}`))
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Transfer-Encoding": "chunked",
      },
    })
  } catch (error) {
    console.error("[v0] Error in analyze route:", {
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
    })
    return new Response(JSON.stringify({ error: "生成报告失败" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
